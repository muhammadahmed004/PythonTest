"""
This module will handle the payment related query and service integration
"""

from .payment import Card
from .external import ExternalPayment
